<?php

namespace App\Http\Livewire;

use App\Models\LiveWireData;
use Livewire\Component;

class Form extends Component
{
    public $name, $email, $number;
    public function updated($field)
    {
        $this->validateOnly($field, [
            'name' => 'required|string',
            'email' => 'required|email|unique:live_wire_data',
            'number' => 'required|integer|min:3|unique:live_wire_data'
        ]);
    }

    public function resetval()
    {
        $this->name = null;
        $this->email = null;
        $this->number = null;
        session()->forget('msg');
    }

    public $alldata;
    public function mount()
    {
        $this->alldata = LiveWireData::all();
    }
    public function submit()
    {
        $this->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:live_wire_data',
            'number' => 'required|integer|unique:live_wire_data'
        ]);

        $data = new LiveWireData;
        $data->name = $this->name;
        $data->email = $this->email;
        $data->number = $this->number;
        $data->save();

        $this->mount();
        $this->resetval();

        return redirect()->with('msg', 'inserted');
    }

    public function render()
    {
        return view('livewire.form');
    }
}
