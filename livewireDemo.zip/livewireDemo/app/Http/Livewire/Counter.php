<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Counter extends Component
{
    // public $count = 0;
    // public function plus()
    // {
    //     $this->count++;
    // }
    // public function minus()
    // {
    //     if ($this->count > 0) {
    //         $this->count--;
    //     }
    // }


    // public $data = array("msg" => "hello");

    public $msg = "Click Submit";

    public function updatemsg()
    {
        $this->msg = "Thank You";
    }
    public function backmsg()
    {
        $this->msg="Submit Please";
    }
    public function render()
    {
        return view('livewire.counter');
    }
}
