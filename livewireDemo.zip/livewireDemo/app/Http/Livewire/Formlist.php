<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\LiveWireData;
use Livewire\WithPagination;

class Formlist extends Component
{

    use WithPagination;
    public $alldatas;
    public $ids = [];
    public $did, $name, $email, $number;
    public $bool = true;


    public function data()
    {
        $this->alldatas = LiveWireData::all();
    }
    public function updateData($id)
    {
        $this->did = $id;
        $data = LiveWireData::find($id);
        $this->name = $data->name;
        $this->email = $data->email;
        $this->number = $data->number;
        $this->bool = false;
    }
    public function deleteData($id)
    {
        $data = LiveWireData::find($id)->delete();
        $this->data();

        return redirect()->with('msg', 'deleted');
    }
    public function deleteMultiple()
    {
        $ids = $this->ids;
        if ($ids != null) {
            LiveWireData::whereIn('id', $ids)->delete();
            return redirect()->with('msg', 'deleted');
        } else {
            return redirect()->with('msg', 'not selected data');
        }
    }

    public function render()
    {

        return view('livewire.formlist', ["alldata" => LiveWireData::simplePaginate(10)]);
    }
}
