<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\LiveWireData;

class Update extends Component
{
    public $did, $name, $email, $number;
    public $bool = true;

    public function render()
    {
        return view('livewire.update');
    }
    public function updated($field)
    {
        $this->validateOnly($field, [
            'name' => 'required|string',
            'email' => 'required|email|unique:live_wire_data',
            'number' => 'required|integer|unique:live_wire_data'
        ]);
    }
    public function update()
    {
        $this->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:live_wire_data',
            'number' => 'required|integer|unique:live_wire_data'
        ]);

        $data = LiveWireData::find($this->did);
        $data->name = $this->name;
        $data->email = $this->email;
        $data->number = $this->number;
        $data->save();
        $this->bool = false;

        return redirect()->with('msg', 'inserted');
    }
}
