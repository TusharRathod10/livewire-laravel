<?php

namespace App\Http\Controllers;

use App\Models\LiveWireData;
use Illuminate\Http\Request;

class MultidelController extends Controller
{
    public function index()
    {
        $data = LiveWireData::all();
        return view('multidel', ['data' => $data]);
    }
    public function delete(Request $request)
    {
        $ids = $request->ids;

        if ($ids != null) {
            LiveWireData::whereIn('id', $ids)->delete();
            return redirect('/multidel')->with('msg', 'deleted');
        } else {
            return redirect('/multidel')->with('msg', 'not selected data');
        }
    }
}
