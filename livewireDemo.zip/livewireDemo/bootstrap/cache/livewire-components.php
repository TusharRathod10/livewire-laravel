<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'form' => 'App\\Http\\Livewire\\Form',
  'formlist' => 'App\\Http\\Livewire\\Formlist',
  'update' => 'App\\Http\\Livewire\\Update',
);