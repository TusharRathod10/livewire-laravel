{{-- <div style="text-align: center">
    <h1>Counter</h1>
    <button wire:click="plus">+</button>
    <h3>{{ $count }}</h3>
    <button wire:click="minus">-</button>
</div> --}}

{{-- <div style="text-align: center">
    <h1>Live Message</h1>
    <input type="text" placeholder="Type Here" wire:model="data.msg" />
    <h3>
        @foreach ($data as $msg)
        {{ $msg }}
        @endforeach
    </h3>
</div> --}}

<div style="text-align: center">
    <h1>Submit Message</h1>
    <form wire:submit.prevent="updatemsg">
        <button type="submit">submit</button>
    </form><br>
    <button type="submit" wire:click="backmsg">back</button>
    <h3>
        {{ $msg }}
    </h3>
</div>
