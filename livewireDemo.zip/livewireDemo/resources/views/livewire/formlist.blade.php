<div>
    @if ($bool==false)
    <livewire:update :did="$did" :name="$name" :email="$email" :number="$number" />
    @else
    <div class="container">
        <h1 class="mt-2">Table</h1>
        <a href="/" class="btn btn-outline-success mb-3 float-end">Add Data</a>
        @if (session()->has('msg'))
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show">
            <div class="alert alert-success my-2 px-5 py-2 position-absolute">
                {{ session()->get('msg') }}
            </div>
        </div>
        @endif
        <table class="table table-light table-hover table-bordered" style="margin-top: 70px;">
            <thead>
                <tr class="text-center">
                    <th scope="col"><button wire:click.prevent="deleteMultiple" class="btn btn-outline-danger">Delete
                            Selected</button></th>
                    <th scope="col">S.No</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Number</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                @foreach($alldata as $item)
                <tr class="text-center">
                    <td><input type="checkbox" wire:model="ids" value="{{ $item->id }}"></td>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->name }}</td>
                    <td>{{ $item->email }}</td>
                    <td>{{ $item->number }}</td>
                    <td><button class="btn btn-primary" wire:click="updateData({{ $item->id }})">edit</button></td>
                    <td><button class="btn btn-danger" wire:click="deleteData({{ $item->id }})">delete</button></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div class="float-end mt-2"> {{ $alldata->links() }}
        </div>
    </div>
    @endif
</div>
