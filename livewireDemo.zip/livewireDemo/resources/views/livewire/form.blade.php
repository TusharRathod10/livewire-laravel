<div>
    <div class="container">
        <h1 class="mt-2">Livewire Basic Form</h1>
        <a href="/data" class="btn btn-outline-success mb-3 float-end">Show Data</a>
        @if (session()->has('msg'))
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show">
            <div class="alert alert-success my-2 px-5 py-2 position-absolute">
                {{ session()->get('msg') }}
            </div>
        </div>
        @endif
        <form wire:submit.prevent="submit" style="margin-top: 70px;">
            <label for="">name : </label>
            <input type="text" wire:model="name" class="form-control">
            @error('name')
            {{ $message }}
            @enderror
            <br>
            <br>
            <label for="">email : </label>
            <input type="email" wire:model="email" class="form-control">
            @error('email')
            {{ $message }}
            @enderror
            <br>
            <br>
            <label for="">number : </label>
            <input type="number" wire:model="number" class="form-control">
            @error('number')
            {{ $message }}
            @enderror
            <br><br>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
<br>
