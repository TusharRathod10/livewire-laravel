



<div style="text-align: center">
    <h1>Submit Message</h1>
    <form wire:submit.prevent="updatemsg">
        <button type="submit">submit</button>
    </form><br>
    <button type="submit" wire:click="backmsg">back</button>
    <h3>
        <?php echo e($msg); ?>

    </h3>
</div>
<?php /**PATH C:\xampp\htdocs\livewireDemo\resources\views/livewire/counter.blade.php ENDPATH**/ ?>