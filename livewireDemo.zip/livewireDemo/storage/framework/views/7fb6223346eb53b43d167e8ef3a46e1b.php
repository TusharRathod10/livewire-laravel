<div>
    <?php if($bool==false): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update', ['did' => $did,'name' => $name,'email' => $email,'number' => $number])->html();
} elseif ($_instance->childHasBeenRendered('l2009547598-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2009547598-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2009547598-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2009547598-0');
} else {
    $response = \Livewire\Livewire::mount('update', ['did' => $did,'name' => $name,'email' => $email,'number' => $number]);
    $html = $response->html();
    $_instance->logRenderedChild('l2009547598-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php else: ?>
    <div class="container">
        <h1 class="mt-2">Table</h1>
        <a href="/" class="btn btn-outline-success mb-3 float-end">Add Data</a>
        <?php if(session()->has('msg')): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show">
            <div class="alert alert-success my-2 px-5 py-2 position-absolute">
                <?php echo e(session()->get('msg')); ?>

            </div>
        </div>
        <?php endif; ?>
        <table class="table table-light table-hover table-bordered" style="margin-top: 70px;">
            <thead>
                <tr class="text-center">
                    <th scope="col"><button wire:click.prevent="deleteMultiple" class="btn btn-outline-danger">Delete
                            Selected</button></th>
                    <th scope="col">S.No</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Number</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><input type="checkbox" wire:model="ids" value="<?php echo e($item->id); ?>"></td>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->number); ?></td>
                    <td><button class="btn btn-primary" wire:click="updateData(<?php echo e($item->id); ?>)">edit</button></td>
                    <td><button class="btn btn-danger" wire:click="deleteData(<?php echo e($item->id); ?>)">delete</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="float-end mt-2"> <?php echo e($alldata->links()); ?>

        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\livewireDemo\resources\views/livewire/formlist.blade.php ENDPATH**/ ?>