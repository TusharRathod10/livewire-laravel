<div>
    <?php if($bool==false): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('formlist', [])->html();
} elseif ($_instance->childHasBeenRendered('l4014101440-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4014101440-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4014101440-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4014101440-0');
} else {
    $response = \Livewire\Livewire::mount('formlist', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4014101440-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php else: ?>
    <div>
        <div class="container">
            <h1 class="mt-2">Livewire Update Form</h1>
            <?php if(session()->has('msg')): ?>
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show">
                <div class="alert alert-success my-2 px-5 py-2 position-absolute">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            </div>
            <?php endif; ?>
            <form wire:submit.prevent="update" style="margin-top: 70px;">
                <label for="">name : </label>
                <input type="text" wire:model="name" class="form-control">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <br>
                <label for="">email : </label>
                <input type="email" wire:model="email" class="form-control">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <br>
                <label for="">number : </label>
                <input type="number" wire:model="number" class="form-control">
                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br><br>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
    <br>

    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\livewireDemo\resources\views/livewire/update.blade.php ENDPATH**/ ?>