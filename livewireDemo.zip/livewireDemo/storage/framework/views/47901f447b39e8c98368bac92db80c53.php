<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@2.8.2/dist/alpine.min.js"></script>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form', [])->html();
} elseif ($_instance->childHasBeenRendered('TxMgtA1')) {
    $componentId = $_instance->getRenderedChildComponentId('TxMgtA1');
    $componentTag = $_instance->getRenderedChildComponentTagName('TxMgtA1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TxMgtA1');
} else {
    $response = \Livewire\Livewire::mount('form', []);
    $html = $response->html();
    $_instance->logRenderedChild('TxMgtA1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\livewireDemo\resources\views/welcome.blade.php ENDPATH**/ ?>